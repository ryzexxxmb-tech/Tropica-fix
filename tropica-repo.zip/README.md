# Tropica (Fabric, MC 26.2)

Репозиторий сам распаковывает jar, исправляет краш
`NullPointerException: Components not bound yet` (`Compat.drinkable`)
и собирает новый jar. Заодно декомпилирует мод в исходники.

## Как пользоваться
1. Положи свой мод в папку `original/` (там уже лежит исходный jar).
2. Вкладка **Actions** → **Build Tropica jar** → **Run workflow**.
3. Когда сборка зелёная, открой её и скачай:
   - **Tropica-fixed** — исправленный jar (клади в `mods`);
   - **Tropica-decompiled-sources** — исходники Java из jar.
4. Для релиза создай тег `v1.0.1` — jar появится в **Releases**.

Нужно для игры: Fabric Loader ≥ 0.19.0, Fabric API, Java 25.

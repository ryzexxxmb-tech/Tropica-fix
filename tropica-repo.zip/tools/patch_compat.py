#!/usr/bin/env python3
"""Патч Tropica: исправляет Compat.drinkable (NPE "Components not bound yet").

Использование: python3 tools/patch_compat.py <вход.jar> <выход.jar>
Метод drinkable(p) становится:  return p.component(CONSUMABLE, Consumables.DEFAULT_DRINK);
"""
import struct, sys, zipfile

CLASS = 'com/tropica/Compat.class'
CONSUMABLES = 'net/minecraft/world/item/Consumables'
FIELD, FIELD_DESC = 'DEFAULT_DRINK', 'Lnet/minecraft/world/item/component/Consumable;'


def u2(d, o): return struct.unpack('>H', d[o:o + 2])[0]


def parse_cp(d):
    off, n = 10, u2(d, 8)
    cp, i = [None] * n, 1
    while i < n:
        t = d[off]
        if t == 1:
            l = u2(d, off + 1); cp[i] = d[off + 3:off + 3 + l].decode('utf8', 'replace'); off += 3 + l
        elif t in (3, 4): off += 5
        elif t in (5, 6): off += 9; i += 1
        elif t in (7, 8, 16, 19, 20): off += 3
        elif t in (9, 10, 11, 12, 17, 18): off += 5
        elif t == 15: off += 4
        else: raise SystemExit('unknown constant tag %d' % t)
        i += 1
    return cp, off, n


def find_index(cp, text):
    return cp.index(text)  # индекс Utf8-записи


def patch(d):
    cp, cp_end, n = parse_cp(d)
    # индексы Fieldref'ов и Methodref'ов находим по существующим данным
    # DataComponents.CONSUMABLE = 7, Item$Properties.component = 33 (проверяется ниже)
    assert cp[11] == 'CONSUMABLE' and cp[37] == 'component', 'неожиданный constant pool'
    def utf8(s):
        b = s.encode(); return b'\x01' + struct.pack('>H', len(b)) + b
    add = utf8(CONSUMABLES)                                   # n
    add += b'\x07' + struct.pack('>H', n)                     # n+1 Class
    add += utf8(FIELD)                                        # n+2
    add += utf8(FIELD_DESC)                                   # n+3
    add += b'\x0c' + struct.pack('>HH', n + 2, n + 3)         # n+4 NameAndType
    add += b'\x09' + struct.pack('>HH', n + 1, n + 4)         # n+5 Fieldref
    fieldref = n + 5
    code = bytes([0x2a, 0xb2, 0, 7, 0xb2]) + struct.pack('>H', fieldref) + bytes([0xb6, 0, 33, 0xb0])
    code_idx = cp.index('Code')
    new_attr = (struct.pack('>HIHHI', code_idx, 12 + len(code), 3, 1, len(code))
                + code + struct.pack('>HH', 0, 0))
    # ищем метод drinkable
    off = cp_end + 6
    off += 2 + 2 * u2(d, off)           # interfaces
    assert u2(d, off) == 0; off += 2    # fields
    mc = u2(d, off); off += 2
    for _ in range(mc):
        name, ac = cp[u2(d, off + 2)], u2(d, off + 6); off += 8
        for _ in range(ac):
            alen = struct.unpack('>I', d[off + 2:off + 6])[0]
            if name == 'drinkable' and cp[u2(d, off)] == 'Code':
                body = d[:8] + struct.pack('>H', n + 6) + d[10:cp_end] + add + d[cp_end:off] \
                       + new_attr + d[off + 6 + alen:]
                return body
            off += 6 + alen
    raise SystemExit('метод drinkable не найден (мод уже исправлен?)')


def main():
    src, dst = sys.argv[1], sys.argv[2]
    zin = zipfile.ZipFile(src)
    d = zin.read(CLASS)
    if CONSUMABLES.encode() in d:
        import shutil; shutil.copy(src, dst)
        print('Уже исправлено, копирую как есть.'); return
    out = patch(d)
    with zipfile.ZipFile(dst, 'w') as zout:
        for i in zin.infolist():
            data = zin.read(i.filename)
            zout.writestr(i, out if i.filename == CLASS else data, compress_type=i.compress_type)
    print('OK ->', dst)


if __name__ == '__main__':
    main()
